import bpy
from bpy.types import Panel

class FOG_PT_main_panel(Panel):
    bl_label = "Fog It"
    bl_idname = "FOG_PT_main_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Fog It"

    def draw(self, context):
        layout = self.layout
        props = context.scene.fog_settings

        # Add/Remove fog buttons
        row = layout.row()
        row.operator("fog.add_fog", text="Add Fog")
        row.operator("fog.remove_fog", text="Remove Fog")

        # Volume properties
        box = layout.box()
        box.label(text="Volume Properties")
        box.prop(props, "volume_size")
        box.prop(props, "start_height")
        box.prop(props, "density")
        box.prop(props, "color")

        # Noise properties
        box = layout.box()
        box.prop(props, "use_noise", text="Use Noise")
        if props.use_noise:
            col = box.column(align=True)
            col.prop(props, "noise_scale")
            col.prop(props, "noise_detail")
            col.prop(props, "noise_roughness")
            col.prop(props, "animate_noise")
            if props.animate_noise:
                col.prop(props, "animation_speed")

        # Height gradient
        box = layout.box()
        box.prop(props, "use_height_gradient")
        if props.use_height_gradient:
            col = box.column(align=True)
            col.prop(props, "gradient_height")

        # Color ramp settings
        box = layout.box()
        box.label(text="Color Ramp Settings")
        col = box.column(align=True)
        col.prop(props, "ramp_position_1")
        col.prop(props, "ramp_color_1")
        col.prop(props, "ramp_position_2")
        col.prop(props, "ramp_color_2")

        # Cycles-specific properties
        if context.scene.render.engine == 'CYCLES':
            box = layout.box()
            box.label(text="Cycles Settings")
            col = box.column(align=True)
            col.prop(props, "anisotropy")
            col.prop(props, "temperature")
