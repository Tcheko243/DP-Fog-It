import bpy
from bpy.types import PropertyGroup
from bpy.props import (FloatProperty, BoolProperty, FloatVectorProperty, 
                      EnumProperty, FloatVectorProperty)

def update_fog(self, context):
    """Update fog when properties change"""
    fog_obj = bpy.data.objects.get("Fog_Volume") or bpy.data.objects.get("Fog_Plane")
    if fog_obj:
        bpy.ops.fog.add_fog('EXEC_DEFAULT')

class FOG_Properties(PropertyGroup):
    volume_size: FloatVectorProperty(
        name="Volume Size",
        description="Size of the fog volume",
        default=(10.0, 10.0, 5.0),
        min=0.1,
        update=update_fog
    )

    start_height: FloatProperty(
        name="Start Height",
        description="Starting height of the fog",
        default=0.0,
        update=update_fog
    )

    density: FloatProperty(
        name="Density",
        description="Fog density",
        default=0.3,
        min=0.0,
        max=10.0,
        update=update_fog
    )

    color: FloatVectorProperty(
        name="Color",
        subtype='COLOR',
        default=(1.0, 1.0, 1.0, 1.0),
        size=4,
        min=0.0,
        max=1.0,
        update=update_fog
    )

    use_noise: BoolProperty(
        name="Use Noise",
        description="Add noise to the fog",
        default=True,
        update=update_fog
    )

    noise_scale: FloatProperty(
        name="Noise Scale",
        description="Scale of the noise pattern",
        default=4.0,
        min=0.0,
        update=update_fog
    )

    noise_detail: FloatProperty(
        name="Noise Detail",
        description="Detail level of the noise",
        default=2.0,
        min=0.0,
        max=16.0,
        update=update_fog
    )

    noise_roughness: FloatProperty(
        name="Noise Roughness",
        description="Roughness of the noise pattern",
        default=0.5,
        min=0.0,
        max=1.0,
        update=update_fog
    )

    animate_noise: BoolProperty(
        name="Animate Noise",
        description="Animate the noise pattern",
        default=False,
        update=update_fog
    )

    animation_speed: FloatProperty(
        name="Animation Speed",
        description="Speed of the noise animation",
        default=1.0,
        min=0.0,
        update=update_fog
    )

    use_height_gradient: BoolProperty(
        name="Use Height Gradient",
        description="Add height-based gradient to the fog",
        default=False,
        update=update_fog
    )

    gradient_height: FloatProperty(
        name="Gradient Height",
        description="Height of the gradient effect",
        default=2.0,
        min=0.1,
        update=update_fog
    )

    ramp_position_1: FloatProperty(
        name="Ramp Position 1",
        default=0.3,
        min=0.0,
        max=1.0,
        update=update_fog
    )

    ramp_position_2: FloatProperty(
        name="Ramp Position 2",
        default=0.7,
        min=0.0,
        max=1.0,
        update=update_fog
    )

    ramp_color_1: FloatVectorProperty(
        name="Ramp Color 1",
        subtype='COLOR',
        default=(1.0, 1.0, 1.0, 1.0),
        size=4,
        min=0.0,
        max=1.0,
        update=update_fog
    )

    ramp_color_2: FloatVectorProperty(
        name="Ramp Color 2",
        subtype='COLOR',
        default=(0.0, 0.0, 0.0, 1.0),
        size=4,
        min=0.0,
        max=1.0,
        update=update_fog
    )

    # Cycles-specific properties
    anisotropy: FloatProperty(
        name="Anisotropy",
        description="Directional scattering of light",
        default=0.0,
        min=-1.0,
        max=1.0,
        update=update_fog
    )

    temperature: FloatProperty(
        name="Temperature",
        description="Temperature of the volume",
        default=1000.0,
        min=0.0,
        update=update_fog
    )
