bl_info = {
    "name": "Fog It",
    "author": "Dimona Patrick",
    "version": (1, 2),
    "blender": (2, 80, 0),
    "location": "View3D > Sidebar > Fog It",
    "description": "Add realistic fog to your scene(2D fog for evee, 3D fog for cycles)",
    "warning": "beta version",
    "doc_url": "",
    "category": "3D View",
}

import bpy
from . import operators
from . import properties
from . import panel

classes = (
    properties.FOG_Properties,
    operators.FOG_OT_add_fog,
    operators.FOG_OT_remove_fog,
    panel.FOG_PT_main_panel,
)

def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.fog_settings = bpy.props.PointerProperty(type=properties.FOG_Properties)

def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
    del bpy.types.Scene.fog_settings

if __name__ == "__main__":
    register()
