import bpy
from bpy.types import Operator
import math
from mathutils import Vector

class FOG_OT_add_fog(Operator):
    bl_idname = "fog.add_fog"
    bl_label = "Add Fog"
    bl_description = "Add volumetric fog to the scene"
    bl_options = {'REGISTER', 'UNDO'}

    def setup_2d_fog_material(self, obj, props):
        # Create new material if it doesn't exist
        mat_name = "Fog_Material_2D"
        mat = bpy.data.materials.get(mat_name)
        if mat:
            mat.node_tree.nodes.clear()
        else:
            mat = bpy.data.materials.new(name=mat_name)
            mat.use_nodes = True
            mat.blend_method = 'BLEND'  # Important for Eevee transparency
            mat.shadow_method = 'NONE'

        nodes = mat.node_tree.nodes
        links = mat.node_tree.links
        
        # Clear existing nodes
        nodes.clear()
        
        # Create nodes
        output = nodes.new('ShaderNodeOutputMaterial')
        transparent = nodes.new('ShaderNodeBsdfTransparent')
        mix = nodes.new('ShaderNodeMixShader')
        emission = nodes.new('ShaderNodeEmission')
        
        # Position nodes for better organization
        output.location = (300, 0)
        mix.location = (100, 0)
        transparent.location = (-100, 100)
        emission.location = (-100, -100)

        # Basic connections
        links.new(transparent.outputs[0], mix.inputs[1])
        links.new(emission.outputs[0], mix.inputs[2])
        links.new(mix.outputs[0], output.inputs[0])

        if props.use_noise:
            # Add noise setup
            tex_coord = nodes.new('ShaderNodeTexCoord')
            mapping = nodes.new('ShaderNodeMapping')
            noise = nodes.new('ShaderNodeTexNoise')
            color_ramp = nodes.new('ShaderNodeValToRGB')
            
            # Position noise nodes
            tex_coord.location = (-700, 0)
            mapping.location = (-500, 0)
            noise.location = (-300, 0)
            color_ramp.location = (-100, 200)

            # Connect noise nodes
            links.new(tex_coord.outputs['Generated'], mapping.inputs[0])
            links.new(mapping.outputs[0], noise.inputs[0])
            links.new(noise.outputs[0], color_ramp.inputs[0])
            links.new(color_ramp.outputs[0], mix.inputs[0])

            # Set noise parameters
            noise.inputs['Scale'].default_value = props.noise_scale
            noise.inputs['Detail'].default_value = props.noise_detail
            noise.inputs['Roughness'].default_value = props.noise_roughness

            # Setup color ramp
            color_ramp.color_ramp.elements[0].position = props.ramp_position_1
            color_ramp.color_ramp.elements[1].position = props.ramp_position_2
            color_ramp.color_ramp.elements[0].color = props.ramp_color_1
            color_ramp.color_ramp.elements[1].color = props.ramp_color_2

            if props.animate_noise:
                self.setup_noise_animation(mapping, props)
        else:
            # If no noise, use density directly
            mix.inputs[0].default_value = props.density

        # Set emission color and strength
        emission.inputs['Color'].default_value = props.color
        emission.inputs['Strength'].default_value = 1.0

        # Apply material to object
        if obj.data.materials:
            obj.data.materials[0] = mat
        else:
            obj.data.materials.append(mat)
            
    def setup_3d_fog_material(self, obj, props):
        # Create new material if it doesn't exist
        mat_name = "Fog_Material_3D"
        mat = bpy.data.materials.get(mat_name)
        if mat:
            mat.node_tree.nodes.clear()
        else:
            mat = bpy.data.materials.new(name=mat_name)
            mat.use_nodes = True

        nodes = mat.node_tree.nodes
        links = mat.node_tree.links

        # Create nodes
        output = nodes.new('ShaderNodeOutputMaterial')
        volume = nodes.new('ShaderNodeVolumePrincipled')
        mapping = nodes.new('ShaderNodeMapping')
        tex_coord = nodes.new('ShaderNodeTexCoord')
        noise = nodes.new('ShaderNodeTexNoise')
        color_ramp = nodes.new('ShaderNodeValToRGB')

        # Basic volume setup
        links.new(volume.outputs[0], output.inputs[1])  # Connect to Volume input
        
        # Set up noise if enabled
        if props.use_noise:
            links.new(tex_coord.outputs['Generated'], mapping.inputs[0])
            links.new(mapping.outputs[0], noise.inputs[0])
            links.new(noise.outputs[0], color_ramp.inputs[0])
            links.new(color_ramp.outputs[0], volume.inputs['Density'])
            
            # Set noise parameters
            noise.inputs['Scale'].default_value = props.noise_scale
            noise.inputs['Detail'].default_value = props.noise_detail
            noise.inputs['Roughness'].default_value = props.noise_roughness
            
            # Set up color ramp
            color_ramp.color_ramp.elements[0].position = props.ramp_position_1
            color_ramp.color_ramp.elements[0].color = props.ramp_color_1
            color_ramp.color_ramp.elements[1].position = props.ramp_position_2
            color_ramp.color_ramp.elements[1].color = props.ramp_color_2
            
            # Setup animation if enabled
            if props.animate_noise:
                self.setup_noise_animation(mapping, props)
        else:
            # If noise is disabled, use constant density
            volume.inputs['Density'].default_value = props.density

        # Set volume properties
        volume.inputs['Color'].default_value = props.color
        volume.inputs['Anisotropy'].default_value = props.anisotropy
        volume.inputs['Temperature'].default_value = props.temperature

        # Height gradient setup if enabled
        if props.use_height_gradient:
            gradient = nodes.new('ShaderNodeTexGradient')
            gradient_mapping = nodes.new('ShaderNodeMapping')
            gradient_color_ramp = nodes.new('ShaderNodeValToRGB')
            
            links.new(tex_coord.outputs['Generated'], gradient_mapping.inputs[0])
            links.new(gradient_mapping.outputs[0], gradient.inputs[0])
            links.new(gradient.outputs[0], gradient_color_ramp.inputs[0])
            
            if props.use_noise:
                math_multiply = nodes.new('ShaderNodeMath')
                math_multiply.operation = 'MULTIPLY'
                links.new(color_ramp.outputs[0], math_multiply.inputs[0])
                links.new(gradient_color_ramp.outputs[0], math_multiply.inputs[1])
                links.new(math_multiply.outputs[0], volume.inputs['Density'])
            else:
                links.new(gradient_color_ramp.outputs[0], volume.inputs['Density'])
            
            # Set gradient parameters
            gradient_mapping.inputs['Scale'].default_value.z = props.gradient_height
            gradient_color_ramp.color_ramp.elements[0].position = 0.0
            gradient_color_ramp.color_ramp.elements[1].position = 1.0

        # Apply material to object
        if obj.data.materials:
            obj.data.materials[0] = mat
        else:
            obj.data.materials.append(mat)

        return mat

    def setup_noise_animation(self, mapping_node, props):
        """Setup noise animation drivers"""
        for i, speed in enumerate([0.01, 0.015, 0.005]):
            driver = mapping_node.inputs['Location'].driver_add('default_value', i).driver
            driver.type = 'SCRIPTED'
            
            # Add variable for frame
            var = driver.variables.new()
            var.name = "frame"
            var.type = 'SINGLE_PROP'
            var.targets[0].id_type = 'SCENE'
            var.targets[0].id = bpy.context.scene
            var.targets[0].data_path = "frame_current"
            
            driver.expression = f"frame * {props.animation_speed} * {speed}"

    def execute(self, context):
        props = context.scene.fog_settings
        is_eevee = context.scene.render.engine == 'BLENDER_EEVEE_NEXT'
        
        # Remove existing fog objects
        for obj_name in ["Fog_Volume", "Fog_Plane"]:
            obj = bpy.data.objects.get(obj_name)
            if obj:
                bpy.data.objects.remove(obj, do_unlink=True)
        
        # Create new fog object based on render engine
        if is_eevee:
            # Create plane for Eevee
            bpy.ops.mesh.primitive_plane_add(
                size=1.0,
                enter_editmode=False,
                align='WORLD'
            )
            fog_obj = context.active_object
            fog_obj.name = "Fog_Plane"
            
            # Set plane size and position
            fog_obj.scale.x = props.volume_size[0]
            fog_obj.scale.y = props.volume_size[1]
            fog_obj.location.z = props.start_height
            
            # Rotate plane to face camera
            fog_obj.rotation_euler.x = math.radians(90)
            
            # Setup material
            mat = self.setup_2d_fog_material(fog_obj, props)
            
            # Set object properties
            fog_obj.show_in_front = True
            #fog_obj.display_type = 'WIRE'  # Makes it easier to select
        else:
            # Create volume for Cycles
            bpy.ops.mesh.primitive_cube_add()
            fog_obj = context.active_object
            fog_obj.name = "Fog_Volume"
            
            # Set volume size and position
            fog_obj.scale = (
                props.volume_size[0]/2,
                props.volume_size[1]/2,
                props.volume_size[2]/2
            )
            fog_obj.location.z = props.start_height + props.volume_size[2]/2
            
            # Setup material
            mat = self.setup_3d_fog_material(fog_obj, props)
            
            # Set object properties
            fog_obj.display_type = 'WIRE'
            fog_obj.show_in_front = True

        # Update viewport
        for area in context.screen.areas:
            if area.type == 'VIEW_3D':
                area.tag_redraw()

        return {'FINISHED'}

class FOG_OT_remove_fog(Operator):
    bl_idname = "fog.remove_fog"
    bl_label = "Remove Fog"
    bl_description = "Remove fog from the scene"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        # Remove fog objects
        for obj_name in ["Fog_Volume", "Fog_Plane"]:
            obj = bpy.data.objects.get(obj_name)
            if obj:
                bpy.data.objects.remove(obj, do_unlink=True)

        # Remove fog materials
        for mat_name in ["Fog_Material_2D", "Fog_Material_3D"]:
            mat = bpy.data.materials.get(mat_name)
            if mat:
                bpy.data.materials.remove(mat, do_unlink=True)

        return {'FINISHED'}


def register():
    bpy.utils.register_class(FOG_OT_add_fog)
    bpy.utils.register_class(FOG_OT_remove_fog)

def unregister():
    bpy.utils.unregister_class(FOG_OT_add_fog)
    bpy.utils.unregister_class(FOG_OT_remove_fog)


